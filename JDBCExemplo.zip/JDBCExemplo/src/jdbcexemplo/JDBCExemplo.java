/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcexemplo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
public class JDBCExemplo {


    public static void main(String[] args) throws SQLException {
       String conexao = "valor";
       try{
           Connection mysql = DriverManager.getConnection("jdbc:mysql://localhost/agenda","root", "12345");
           
           
           String sql = "delete from contatos where id = 2";
           
           PreparedStatement instrucao = mysql.prepareStatement(sql);
            
           
           instrucao.execute();
           
           System.out.println("Conectado!");
           
       }
       catch (SQLException e){
        System.out.println("Ocorreu um erro!");
        throw new RuntimeException(e.getMessage());
    }
    }
    
}
